import pygame, sys, tkinter, math, random
from tkinter import filedialog

pygame.init()

WIDTH, HEIGHT = 1280, 960

screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.SCALED)
pygame.display.set_caption('PokéPaint')

background = pygame.transform.scale(
	pygame.image.load('../assets/paintproject_background.png'),(1280,960))
screen.blit(background, (0,0))

logo = pygame.transform.scale(
	pygame.image.load('../assets/pokemon.png'),(300,111))
logowidth = logo.get_width()
screen.blit(logo, (WIDTH//2 - logowidth//2,0))

canvasRect = pygame.Rect(250,250,980,660)
canvasRectOutline =  pygame.Rect(245,245,990,670)
pygame.draw.rect(screen,'black',canvasRectOutline)
pygame.draw.rect(screen,'white',canvasRect)
screenCap=screen.subsurface(canvasRect).copy()

colorPalette = pygame.transform.scale(
	pygame.image.load('../assets/fullrbgcolorpalette.png'),(200,150))
screen.blit(colorPalette,(20,765))
colorPaletteRect = pygame.Rect(20,765,200,150)

tools=['pencil', 'eraser','spraypaint','paintbrush','line','ellipse','rectangle','pokeball','greatball','ultraball','masterball','duskball']
uiItems=['save','load']
tool='pencil'
toolRects=[]
uiRects=[]
imageRects=[]
uiImages = []
user_size=5
fill_status=0

for t in tools:
	image = pygame.transform.scale(
		pygame.image.load(f'../assets/{t}.png').convert_alpha(),(60,60))
	imageRects.append(image)
for u in uiItems:
	image = pygame.transform.scale(
		pygame.image.load(f'../assets/{t}.png').convert_alpha(),(60,60))
	uiItems.append(image)

pokeballstamp = pygame.transform.scale(
	pygame.image.load('../assets/pokeball.png'),(100,100))
pygame.display.set_icon(pokeballstamp)
greatballstamp = pygame.transform.scale(
	pygame.image.load('../assets/greatball.png'),(100,100))
ultraballstamp = pygame.transform.scale(
	pygame.image.load('../assets/ultraball.png'),(100,100))
masterballstamp = pygame.transform.scale(
	pygame.image.load('../assets/masterball.png'),(100,100))
duskballstamp = pygame.transform.scale(
	pygame.image.load('../assets/duskball.png'),(100,100))


pencilRect = pygame.Rect(10,250,70,70)
toolRects.append(pencilRect)

eraserRect = pygame.Rect(90,250,70,70)
toolRects.append(eraserRect)

spraypaintRect = pygame.Rect(170,250,70,70)
toolRects.append(spraypaintRect)

paintbrushRect = pygame.Rect(10,330,70,70)
toolRects.append(paintbrushRect)

lineRect = pygame.Rect(90,330,70,70)
toolRects.append(lineRect)

ellipseRect = pygame.Rect(170,330,70,70)
toolRects.append(ellipseRect)

rectRect = pygame.Rect(10,410,70,70)
toolRects.append(rectRect)

saveRect = pygame.Rect(90,410,70,70)
uiRects.append(saveRect)

loadRect = pygame.Rect(170,410,70,70)
uiRects.append(loadRect)

pokeballRect = pygame.Rect(250,140,70,70)
toolRects.append(pokeballRect)

greatballRect = pygame.Rect(360,140,70,70)
toolRects.append(greatballRect)

ultraballRect = pygame.Rect(470,140,70,70)
toolRects.append(ultraballRect)

masterballRect = pygame.Rect(580,140,70,70)
toolRects.append(masterballRect)

duskballRect = pygame.Rect(690,140,70,70)
toolRects.append(duskballRect)

selected_color='black'

FPS = pygame.time.Clock()

omx, omy = 0, 0


def main(tool,screenCap,selected_color,fill_status):
	while True:
		for event in pygame. event.get():
			if event.type ==pygame.QUIT:
				pygame.quit()
				sys.exit()
			if event.type == pygame.MOUSEBUTTONDOWN:
				if event.button == 1:
					if canvasRect.collidepoint(event.pos):
						dmx, dmy = event.pos
			if event.type == pygame.MOUSEBUTTONUP:
				if event.button == 1:
						screenCap=screen.subsurface(canvasRect).copy()
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_f:
					if fill_status == 0:
						fill_status = 1
					else:
						fill_status = 0

		mx,my = pygame.mouse.get_pos()
		mb = pygame.mouse.get_pressed()
		keys= pygame.key.get_pressed()

		for toolrect in toolRects:
			if toolrect.collidepoint(mx,my):
				pygame.draw.rect(screen,'red',toolrect)
			elif tools.index(tool) == toolRects.index(toolrect):
				pygame.draw.rect(screen,'green',toolrect)
			else:
				pygame.draw.rect(screen,'white',toolrect)
			screen.blit(
					imageRects[toolRects.index(toolrect)],(toolrect.x+5,toolrect.y+5))
				
			if mb[0] and toolrect.collidepoint(mx,my):
				tool = tools[toolRects.index(toolrect)]

		for uirect in uiRects:
			if uirect.collidepoint(mx,my):
				pygame.draw.rect(screen,'red',uirect)
			else:
				pygame.draw.rect(screen,'white',uirect)
			screen.blit(
				imageRects[uiRects.index(uirect)],(uirect.x+5,uirect.y+5))


		if mb[0] and canvasRect.collidepoint(mx,my):
			draw(tool,screenCap,user_size,selected_color,keys,omx,omy,mx,my,dmx,dmy,fill_status)

		if mb[0] and colorPaletteRect.collidepoint(mx,my):
			selected_color=screen.get_at((mx,my))
			
		omx,omy = mx,my
		FPS.tick(2000)
		pygame.display.flip()

def draw(tool,screenCap,user_size,selected_color,keys,omx,omy,mx,my,dmx,dmy,fill_status):
	screen.set_clip(canvasRect)
	if tool == 'pencil':
		pygame.draw.line(screen,selected_color,(omx,omy),(mx,my))
	elif tool == 'eraser':
		pygame.draw.circle(screen,'white',(mx,my),user_size)
	elif tool == 'spraypaint':
		for i in range(10):
			pygame.draw.circle(screen, selected_color, (random.randint(mx-20,mx+20),random.randint(my-20,my+20)),1)
	elif tool == 'paintbrush':
		pygame.draw.circle(screen,selected_color,(mx,my),user_size)
	elif tool == 'line':
		screen.blit(screenCap,canvasRect)
		pygame.draw.line(screen,selected_color,(dmx,dmy),(mx,my))
	elif tool == 'ellipse':
		if keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]:
			screen.blit(screenCap,canvasRect)
			distance = math.sqrt((dmx-mx)**2 + (dmy-my)**2)
			pygame.draw.circle(screen,selected_color,(dmx,dmy),distance,fill_status)
		else:
			screen.blit(screenCap,canvasRect)
			if dmx>mx:
				if dmy>my:
					ellipseDrawRect = pygame.Rect(mx,my,dmx-mx,dmy-my)
				else:
					ellipseDrawRect = pygame.Rect(mx,dmy,dmx-mx,my-dmy)
			else:
				if dmy>my:
					ellipseDrawRect = pygame.Rect(dmx,my,mx-dmx,dmy-my)
				else:
					ellipseDrawRect = pygame.Rect(dmx,dmy,mx-dmx,my-dmy)
			pygame.draw.ellipse(screen,selected_color,ellipseDrawRect,fill_status)
	elif tool == 'rectangle':
		screen.blit(screenCap,canvasRect)
		if dmx>mx:
			if dmy>my:
				pygame.draw.rect(screen,selected_color,(mx,my,dmx-mx,dmy-my),fill_status)
			else:
				pygame.draw.rect(screen,selected_color,(mx,dmy,dmx-mx,my-dmy),fill_status)
		else:
			if dmy>my:
				pygame.draw.rect(screen,selected_color,(dmx,my,mx-dmx,dmy-my),fill_status)
			else:
				pygame.draw.rect(screen,selected_color,(dmx,dmy,mx-dmx,my-dmy),fill_status)
	elif tool == 'pokeball':
		screen.blit(screenCap,canvasRect)
		screen.blit(pokeballstamp,(mx-50,my-50))
	elif tool == 'greatball':
		screen.blit(screenCap,canvasRect)
		screen.blit(greatballstamp,(mx-50,my-50))
	elif tool == 'ultraball':
		screen.blit(screenCap,canvasRect)
		screen.blit(ultraballstamp,(mx-50,my-50))
	elif tool == 'masterball':
		screen.blit(screenCap,canvasRect)
		screen.blit(masterballstamp,(mx-50,my-50))
	elif tool == 'duskball':
		screen.blit(screenCap,canvasRect)
		screen.blit(duskballstamp,(mx-50,my-50))
	screen.set_clip(None)


main(tool,screenCap,selected_color,fill_status)