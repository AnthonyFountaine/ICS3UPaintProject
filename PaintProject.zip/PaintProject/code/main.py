import pygame,sys, tkinter, math, random, time
from tkinter import filedialog

pygame.init()
tkinter.Tk().withdraw()

WIDTH, HEIGHT = 1280, 800

screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.SCALED)
pygame.display.set_caption('PokéPaint')

background = pygame.transform.scale(
	pygame.image.load('../assets/paintproject_background.png'),(1280,960))
screen.blit(background, (0,0))

logo = pygame.transform.scale(
	pygame.image.load('../assets/pokemon.png'),(300,111))
logowidth = logo.get_width()
screen.blit(logo, (WIDTH//2 - logowidth//2,0))

canvasRect = pygame.Rect(250,250,854,480)
canvasRectOutline =  pygame.Rect(245,245,864,490)
pygame.draw.rect(screen,'black',canvasRectOutline)
pygame.draw.rect(screen,'white',canvasRect)
screenCap=screen.subsurface(canvasRect).copy()

colorPalette = pygame.transform.scale(
	pygame.image.load('../assets/fullrbgcolorpalette.png'),(200,150))
screen.blit(colorPalette,(20,605))
colorPaletteRect = pygame.Rect(20,605,200,150)

tools=['pencil', 'eraser','spraypaint','paintbrush','line','ellipse','rectangle','pokeball','greatball','ultraball','masterball','duskball']
uiItems=['save','upload']
tool='pencil'
toolRects=[]
uiRects=[]
images=[]
uiImages=[]
user_size=5
fill_status=0

for t in tools:
	image = pygame.transform.scale(
		pygame.image.load(f'../assets/{t}.png'),(60,60))
	images.append(image)

for u in uiItems:
	image = pygame.transform.scale(
		pygame.image.load(f'../assets/{u}.png'),(60,60))
	uiImages.append(image)

pokeballstamp = pygame.transform.scale(
	pygame.image.load('../assets/pokeball.png'),(100,100))
pygame.display.set_icon(pokeballstamp)
greatballstamp = pygame.transform.scale(
	pygame.image.load('../assets/greatball.png'),(100,100))
ultraballstamp = pygame.transform.scale(
	pygame.image.load('../assets/ultraball.png'),(100,100))
masterballstamp = pygame.transform.scale(
	pygame.image.load('../assets/masterball.png'),(100,100))
duskballstamp = pygame.transform.scale(
	pygame.image.load('../assets/duskball.png'),(100,100))


pencilRect = pygame.Rect(10,250,70,70)
toolRects.append(pencilRect)

eraserRect = pygame.Rect(90,250,70,70)
toolRects.append(eraserRect)

spraypaintRect = pygame.Rect(170,250,70,70)
toolRects.append(spraypaintRect)

paintbrushRect = pygame.Rect(10,330,70,70)
toolRects.append(paintbrushRect)

lineRect = pygame.Rect(90,330,70,70)
toolRects.append(lineRect)

ellipseRect = pygame.Rect(170,330,70,70)
toolRects.append(ellipseRect)

rectRect = pygame.Rect(10,410,70,70)
toolRects.append(rectRect)

saveRect = pygame.Rect(10,10,70,70)
uiRects.append(saveRect)

uploadRect = pygame.Rect(90,10,70,70)
uiRects.append(uploadRect)

pokeballRect = pygame.Rect(250,140,70,70)
toolRects.append(pokeballRect)

greatballRect = pygame.Rect(360,140,70,70)
toolRects.append(greatballRect)

ultraballRect = pygame.Rect(470,140,70,70)
toolRects.append(ultraballRect)

masterballRect = pygame.Rect(580,140,70,70)
toolRects.append(masterballRect)

duskballRect = pygame.Rect(690,140,70,70)
toolRects.append(duskballRect)

selected_color='black'

FPS = pygame.time.Clock()

omx, omy = 0, 0


def main(tool,screenCap,selected_color,fill_status):
	while True:
		for event in pygame. event.get():
			if event.type ==pygame.QUIT:
				pygame.quit()
				sys.exit()
			if event.type == pygame.MOUSEBUTTONDOWN:
				if event.button == 1:
					if saveRect.collidepoint(mx,my):
						save()
						'''
						When calling the save function, the pygame window goes out of focus
						You must click back on the window to draw again making it look like it is broken
						'''
					if uploadRect.collidepoint(mx,my):
						upload()
						'''
						When calling the upload function, the pygame window goes out of focus
						You must click back on the window to draw again making it look like it is broken
						'''
					dmx, dmy = event.pos
					if canvasRect.collidepoint(event.pos):
						if tool == 'paintbrush':
							pygame.draw.circle(screen,selected_color,(mx,my),user_size-2)
						if tool == 'eraser':
							pygame.draw.circle(screen,'white',(mx,my),user_size-2)

			if event.type == pygame.MOUSEBUTTONUP:
				if event.button == 1:
						if canvasRect.collidepoint(mx,my):

							if tool == 'paintbrush':
								pygame.draw.circle(screen,selected_color,(mx,my),user_size-2)
							if tool == 'eraser':
								pygame.draw.circle(screen,'white',(mx,my),user_size-2)
						screenCap=screen.subsurface(canvasRect).copy()
						
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_f:
					if fill_status == 0:
						fill_status = 1
					else:
						fill_status = 0

		mx,my = pygame.mouse.get_pos()
		mb = pygame.mouse.get_pressed()
		keys= pygame.key.get_pressed()

		for toolrect in toolRects:
			if toolrect.collidepoint(mx,my):
				pygame.draw.rect(screen,'red',toolrect)
			elif tools.index(tool) == toolRects.index(toolrect):
				pygame.draw.rect(screen,'green',toolrect)
			else:
				pygame.draw.rect(screen,'white',toolrect)
			screen.blit(
					images[toolRects.index(toolrect)],(toolrect.x+5,toolrect.y+5))
				
			if mb[0] and toolrect.collidepoint(mx,my):
				tool = tools[toolRects.index(toolrect)]

		for uiRect in uiRects:
			if uiRect.collidepoint(mx,my):
				pygame.draw.rect(screen,'red',uiRect)
			else:
				pygame.draw.rect(screen,'white',uiRect)
			screen.blit(
					uiImages[uiRects.index(uiRect)],(uiRect.x+5,uiRect.y+5))

		if mb[0] and canvasRect.collidepoint(mx,my):
			draw(tool,screenCap,user_size,selected_color,keys,omx,omy,mx,my,dmx,dmy,fill_status,saveupload)

		if mb[0] and colorPaletteRect.collidepoint(mx,my):
			selected_color=screen.get_at((mx,my))
		
		saveupload=False
		omx,omy = mx,my
		FPS.tick(2000)
		pygame.display.flip()



def draw(tool,screenCap,user_size,selected_color,keys,omx,omy,mx,my,dmx,dmy,fill_status,saveupload):
	screen.set_clip(canvasRect)
	if tool == 'pencil':
		pygame.draw.line(screen,selected_color,(omx,omy),(mx,my))
	elif tool == 'eraser':
		pygame.draw.circle(screen,'white',(mx,my),user_size)
	elif tool == 'spraypaint':
		pixelstopaint=[]
		for i in range(2):
			while True:
				point = (random.randint(mx-20,mx+20),random.randint(my-20,my+20))
				distance = math.sqrt((point[0]-mx)**2 + (point[1]-my)**2)
				if distance<=user_size*3:
					pixelstopaint.append(point)
					break
		for p in pixelstopaint:
			pygame.draw.circle(screen,selected_color,p,0.5)
	elif tool == 'paintbrush':
		pygame.draw.line(screen,selected_color,(omx,omy),(mx,my),user_size)
	elif tool == 'line':
		screen.blit(screenCap,canvasRect)
		pygame.draw.line(screen,selected_color,(dmx,dmy),(mx,my))
	elif tool == 'ellipse':
		if keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]:
			screen.blit(screenCap,canvasRect)
			distance = math.sqrt((dmx-mx)**2 + (dmy-my)**2)
			pygame.draw.circle(screen,selected_color,(dmx,dmy),distance,fill_status)
		else:
			screen.blit(screenCap,canvasRect)
			if dmx>mx:
				if dmy>my:
					ellipseDrawRect = pygame.Rect(mx,my,dmx-mx,dmy-my)
				else:
					ellipseDrawRect = pygame.Rect(mx,dmy,dmx-mx,my-dmy)
			else:
				if dmy>my:
					ellipseDrawRect = pygame.Rect(dmx,my,mx-dmx,dmy-my)
				else:
					ellipseDrawRect = pygame.Rect(dmx,dmy,mx-dmx,my-dmy)
			pygame.draw.ellipse(screen,selected_color,ellipseDrawRect,fill_status)
	elif tool == 'rectangle':
		screen.blit(screenCap,canvasRect)
		if dmx>mx:
			if dmy>my:
				pygame.draw.rect(screen,selected_color,(mx,my,dmx-mx,dmy-my),fill_status)
			else:
				pygame.draw.rect(screen,selected_color,(mx,dmy,dmx-mx,my-dmy),fill_status)
		else:
			if dmy>my:
				pygame.draw.rect(screen,selected_color,(dmx,my,mx-dmx,dmy-my),fill_status)
			else:
				pygame.draw.rect(screen,selected_color,(dmx,dmy,mx-dmx,my-dmy),fill_status)
	elif tool == 'pokeball':
		screen.blit(screenCap,canvasRect)
		screen.blit(pokeballstamp,(mx-50,my-50))
	elif tool == 'greatball':
		screen.blit(screenCap,canvasRect)
		screen.blit(greatballstamp,(mx-50,my-50))
	elif tool == 'ultraball':
		screen.blit(screenCap,canvasRect)
		screen.blit(ultraballstamp,(mx-50,my-50))
	elif tool == 'masterball':
		screen.blit(screenCap,canvasRect)
		screen.blit(masterballstamp,(mx-50,my-50))
	elif tool == 'duskball':
		screen.blit(screenCap,canvasRect)
		screen.blit(duskballstamp,(mx-50,my-50))
	screen.set_clip(None)

def save():
	try:
		fname=tkinter.filedialog.asksaveasfilename(defaultextension=".png")
		if len(fname) == 0:
			pass
		pygame.image.save(screen.subsurface(canvasRect),fname)
		
	except:
		print('No file selected')

def upload():
	try:
		fname=filedialog.askopenfilename()
		if len(fname) == 0:
			pass
		dot = fname.rfind('.')
		ext = fname[dot+1:]
		if ext == 'png':
			image = pygame.image.load(fname)
			imageRect = image.get_rect()
			if imageRect.width>canvasRect.width:
				if imageRect.height>canvasRect.height:
					pygame.transform.scale(image,(canvasRect.width,canvasRect.height))
				else:
					pygame.transform.scale(image,(canvasRect.width,imageRect.height))
			else:
				if imageRect.y>canvasRect.y:
					pygame.transform.scale(image,(imageRect.width,canvasRect.height))
			pygame.draw.rect(screen,'white',canvasRect)
			screen.blit(image,(250,250))
			
	except:
		print('No file selected')
main(tool,screenCap,selected_color,fill_status)